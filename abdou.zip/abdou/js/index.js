/* particlesJS.load(@dom-id, @path-json, @callback (optional)); */
particlesJS.load('particles-js', './js/particles.json', function() {
    console.log('callback - particles.js config loaded');
});

$("body").niceScroll({
    cursorcolor:"#6f6e66",
    cursorwidth:"10px"
});